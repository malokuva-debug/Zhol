"use client";

import { useEffect, useState } from "react";
import { Reorder } from "framer-motion";
import PlayingCard from "./PlayingCard";
import type { CardId } from "@/lib/types";

/**
 * Renders the player's hand as a held card-fan (arced rotation + overlap)
 * that can be drag-reordered to sort it however the player likes. Sorting is
 * purely a local display preference — it doesn't touch game state, so it
 * never needs a round-trip to the server.
 *
 * Important: the fan's rotate/vertical-arc offset is applied to a plain
 * inner wrapper, NOT to the Reorder.Item itself. Reorder.Item is a motion
 * element that manages its own transform for the x-axis drag/swap animation;
 * layering our own `y`/`rotate` motion values directly onto that same
 * element fights with Framer's internal layout transform mid-drag and causes
 * cards to visibly jump to inconsistent heights. Keeping the two transforms
 * on separate elements keeps every card's baseline stable at all times.
 */
export default function HandFan({
  cards,
  selectedCard,
  onSelect,
  interactive,
}: {
  cards: CardId[];
  selectedCard: string | null;
  onSelect: (id: string) => void;
  interactive: boolean;
}) {
  const [order, setOrder] = useState<CardId[]>(cards);

  // Keep local order in sync with the authoritative hand: preserve whatever
  // arrangement the player has dragged into, just append newly-drawn cards
  // and drop whatever got discarded.
  useEffect(() => {
    setOrder((prev) => {
      const stillHere = prev.filter((id) => cards.includes(id));
      const added = cards.filter((id) => !prev.includes(id));
      return [...stillHere, ...added];
    });
  }, [cards]);

  const n = order.length;
  const center = (n - 1) / 2;
  const angleStep = n > 1 ? Math.min(6, 60 / n) : 0;
  const overlapPx = n > 9 ? 34 : 30;

  return (
    <Reorder.Group
      axis="x"
      values={order}
      onReorder={setOrder}
      className="flex items-end justify-center px-4 py-3"
      style={{ listStyle: "none" }}
    >
      {order.map((id, i) => {
        const offset = i - center;
        const rotate = offset * angleStep;
        const arcY = Math.abs(offset) * (angleStep * 1.1);
        const isSelected = selectedCard === id;

        return (
          <Reorder.Item
            key={id}
            value={id}
            style={{
              marginLeft: i === 0 ? 0 : -overlapPx,
              zIndex: isSelected ? 100 : i,
            }}
            whileDrag={{ scale: 1.08, zIndex: 200 }}
            className="cursor-grab touch-none active:cursor-grabbing"
          >
            {/* Fan curve lives here, isolated from Reorder's own drag transform */}
            <div
              style={{
                transform: `rotate(${rotate}deg) translateY(${isSelected ? arcY - 22 : arcY}px)`,
                transformOrigin: "bottom center",
                transition: "transform 0.18s ease",
              }}
            >
              <PlayingCard id={id} selected={isSelected} onClick={interactive ? () => onSelect(id) : undefined} />
            </div>
          </Reorder.Item>
        );
      })}
    </Reorder.Group>
  );
}

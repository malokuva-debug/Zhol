import type { Card, CardId, Meld, Rank, Suit, GinType } from "./types";

const SUITS: Suit[] = ["S", "H", "D", "C"];
const RANKS: Rank[] = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];

/**
 * ASSUMPTION (undocumented in the brief): an unmelded joker left in a losing
 * hand counts as 15 deadwood points. This value is centralized here so it's
 * a one-line change if your house rule differs.
 */
export const JOKER_DEADWOOD_VALUE = 15;

export function cardValue(rank: Rank): number {
  // Kosovo-style: number cards = face value, A/J/Q/K all count as 10.
  if (rank === "J" || rank === "Q" || rank === "K" || rank === "A") return 10;
  return parseInt(rank, 10);
}

export function isJokerId(id: CardId): boolean {
  return id.startsWith("JK");
}

export function makeCard(id: CardId): Card {
  if (isJokerId(id)) {
    return { id, rank: "JOKER", suit: null, value: 0, isJoker: true };
  }
  const base = id.split("_")[0]; // strip "_2" deck-disambiguation suffix
  const suit = base.slice(-1) as Suit;
  const rank = base.slice(0, -1) as Rank;
  return { id, rank, suit, value: cardValue(rank), isJoker: false };
}

/** Builds N standard 52-card decks plus the given number of jokers, all with unique ids. */
export function freshDeckIds(numDecks: 1 | 2 = 1, jokerCount: 0 | 2 | 4 = 2): CardId[] {
  const ids: CardId[] = [];
  for (let d = 0; d < numDecks; d++) {
    const suffix = d === 0 ? "" : `_${d + 1}`;
    for (const s of SUITS) for (const r of RANKS) ids.push(`${r}${s}${suffix}`);
  }
  for (let j = 0; j < jokerCount; j++) ids.push(`JK${j + 1}`);
  return ids;
}

export function shuffle<T>(arr: T[]): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const RANK_LOW: Record<Rank, number> = {
  A: 1, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9, "10": 10, J: 11, Q: 12, K: 13,
};
// Ace-high numbering — used only to detect Q-K-A. Every other rank keeps the
// same value as RANK_LOW, so a chain can never accidentally bridge across the
// ace both ways (K-A-2 correctly fails: 13, 14, 2 is not consecutive).
const RANK_HIGH: Record<Rank, number> = { ...RANK_LOW, A: 14 };

interface RealMeld extends Meld {
  usesJoker: 0 | 1 | 2;
}

/** All valid real-card-only sets and runs (no wildcards), both ace numberings. */
function candidateRealMelds(cards: Card[]): RealMeld[] {
  const melds: RealMeld[] = [];

  const byRank = new Map<Rank, Card[]>();
  for (const c of cards) {
    if (c.isJoker) continue;
    const r = c.rank as Rank;
    if (!byRank.has(r)) byRank.set(r, []);
    byRank.get(r)!.push(c);
  }
  for (const [, group] of byRank) {
    if (group.length >= 3) {
      melds.push({ type: "set", cards: group.map((c) => c.id), usesJoker: 0 });
      if (group.length === 4) {
        for (let skip = 0; skip < 4; skip++) {
          melds.push({ type: "set", cards: group.filter((_, i) => i !== skip).map((c) => c.id), usesJoker: 0 });
        }
      }
    }
  }

  const bySuit = new Map<Suit, Card[]>();
  for (const c of cards) {
    if (c.isJoker) continue;
    const s = c.suit as Suit;
    if (!bySuit.has(s)) bySuit.set(s, []);
    bySuit.get(s)!.push(c);
  }
  for (const [, group] of bySuit) {
    for (const numbering of [RANK_LOW, RANK_HIGH]) {
      const sorted = [...group].sort((a, b) => numbering[a.rank as Rank] - numbering[b.rank as Rank]);
      let chainStart = 0;
      for (let i = 1; i <= sorted.length; i++) {
        const broke = i === sorted.length || numbering[sorted[i].rank as Rank] !== numbering[sorted[i - 1].rank as Rank] + 1;
        if (broke) {
          const chain = sorted.slice(chainStart, i);
          for (let len = 3; len <= chain.length; len++) {
            for (let start = 0; start + len <= chain.length; start++) {
              melds.push({ type: "run", cards: chain.slice(start, start + len).map((c) => c.id), usesJoker: 0 });
            }
          }
          chainStart = i;
        }
      }
    }
  }

  return melds;
}

/**
 * Expands real-card melds with joker-substituted variants: a rank group one
 * card short of a set, or a run chain one card short (internal gap or a
 * one-card extension at either end), can complete using a joker as a wildcard.
 *
 * This covers the common cases; it does not attempt every exotic multi-gap
 * wildcard placement (e.g. two separate 1-card gaps bridged by two different
 * jokers in the same run) — a documented simplification given jokers are
 * capped at 2-4 per deck and hands are small.
 */
function candidateJokerMelds(cards: Card[], jokersAvailable: number): RealMeld[] {
  if (jokersAvailable <= 0) return [];
  const melds: RealMeld[] = [];

  const byRank = new Map<Rank, Card[]>();
  for (const c of cards) {
    if (c.isJoker) continue;
    const r = c.rank as Rank;
    if (!byRank.has(r)) byRank.set(r, []);
    byRank.get(r)!.push(c);
  }
  for (const [, group] of byRank) {
    // 3-set = any 2 real cards of this rank + 1 joker (frees the rest of the group, if any)
    if (jokersAvailable >= 1 && group.length >= 2) {
      for (let a = 0; a < group.length; a++) {
        for (let b = a + 1; b < group.length; b++) {
          melds.push({ type: "set", cards: [group[a].id, group[b].id, "__JOKER__"], usesJoker: 1 });
        }
      }
    }
    // 4-set = any 3 real cards of this rank + 1 joker (frees the excluded card — this is the
    // case that matters when all 4 suits of a rank are present but you want to use only 3
    // of them here and the 4th elsewhere, e.g. in a run).
    if (jokersAvailable >= 1 && group.length >= 3) {
      for (let exclude = 0; exclude < group.length; exclude++) {
        const subset = group.filter((_, i) => i !== exclude);
        if (subset.length === 3) {
          melds.push({ type: "set", cards: subset.map((c) => c.id).concat(["__JOKER__"]), usesJoker: 1 });
        }
      }
    }
    // 3-set = 1 real card of this rank + 2 jokers
    if (jokersAvailable >= 2 && group.length >= 1) {
      for (const c of group) {
        melds.push({ type: "set", cards: [c.id, "__JOKER__", "__JOKER__"], usesJoker: 2 });
      }
    }
  }

  const bySuit = new Map<Suit, Card[]>();
  for (const c of cards) {
    if (c.isJoker) continue;
    const s = c.suit as Suit;
    if (!bySuit.has(s)) bySuit.set(s, []);
    bySuit.get(s)!.push(c);
  }
  for (const [, group] of bySuit) {
    for (const numbering of [RANK_LOW, RANK_HIGH]) {
      const present = new Map<number, Card>();
      for (const c of group) present.set(numbering[c.rank as Rank], c);
      const values = [...present.keys()].sort((a, b) => a - b);

      // one internal gap of exactly 1, bridged by a joker
      for (let i = 0; i < values.length - 1; i++) {
        if (values[i + 1] - values[i] === 2 && jokersAvailable >= 1) {
          // find the full contiguous span this gap sits inside (values[i]..values[i+1])
          const spanCards = [present.get(values[i])!, present.get(values[i + 1])!];
          if (spanCards.length + 1 >= 3) {
            melds.push({ type: "run", cards: [spanCards[0].id, "__JOKER__", spanCards[1].id], usesJoker: 1 });
          }
        }
      }
      // extend a 2-card consecutive chain by one joker at either end
      for (let i = 0; i < values.length - 1; i++) {
        if (values[i + 1] - values[i] === 1 && jokersAvailable >= 1) {
          const a = present.get(values[i])!;
          const b = present.get(values[i + 1])!;
          melds.push({ type: "run", cards: ["__JOKER__", a.id, b.id], usesJoker: 1 });
          melds.push({ type: "run", cards: [a.id, b.id, "__JOKER__"], usesJoker: 1 });
        }
      }
      // lone card + 2 jokers
      if (jokersAvailable >= 2) {
        for (const v of values) {
          const c = present.get(v)!;
          melds.push({ type: "run", cards: ["__JOKER__", c.id, "__JOKER__"], usesJoker: 2 });
        }
      }
    }
  }

  return melds;
}

interface MeldSolution {
  deadwood: number;
  melds: RealMeld[];
  deadCards: CardId[];
  jokersUsed: number;
  jokersUnused: number;
}

/**
 * Finds the meld arrangement that minimizes total deadwood for a hand,
 * accounting for jokers as wildcards. Search space is small (≤11 cards,
 * ≤4 jokers) so plain recursive backtracking is instant.
 */
export function minimizeDeadwood(handIds: CardId[]): MeldSolution {
  const allCards = handIds.map(makeCard);
  const realCards = allCards.filter((c) => !c.isJoker);
  const jokerIds = allCards.filter((c) => c.isJoker).map((c) => c.id);
  const jokerCount = jokerIds.length;
  const cardMap = new Map(realCards.map((c) => [c.id, c]));

  const candidates = [...candidateRealMelds(realCards), ...candidateJokerMelds(realCards, jokerCount)];

  let best: MeldSolution | null = null;

  function score(remainingReal: Set<CardId>, jokersUnused: number): number {
    let dead = 0;
    for (const id of remainingReal) dead += cardMap.get(id)!.value;
    dead += jokersUnused * JOKER_DEADWOOD_VALUE;
    return dead;
  }

  function search(remainingReal: Set<CardId>, jokersLeft: number, chosen: RealMeld[], startIdx: number) {
    const deadwood = score(remainingReal, jokersLeft);
    if (!best || deadwood < best.deadwood) {
      best = {
        deadwood,
        melds: [...chosen],
        deadCards: [...remainingReal],
        jokersUsed: jokerCount - jokersLeft,
        jokersUnused: jokersLeft,
      };
    }
    if (deadwood === 0) return;

    for (let i = startIdx; i < candidates.length; i++) {
      const m = candidates[i];
      const realNeeded = m.cards.filter((c) => c !== "__JOKER__");
      if (m.usesJoker > jokersLeft) continue;
      if (!realNeeded.every((c) => remainingReal.has(c))) continue;

      const next = new Set(remainingReal);
      realNeeded.forEach((c) => next.delete(c));
      search(next, jokersLeft - m.usesJoker, [...chosen, m], i + 1);
    }
  }

  search(new Set(realCards.map((c) => c.id)), jokerCount, [], 0);
  return best!;
}

export function canGin(handIds: CardId[]): boolean {
  const solution = minimizeDeadwood(handIds);
  return solution.deadwood === 0 && solution.jokersUnused === 0;
}

/** Determines the win-category (and thus bonus) for a fully-melded winning hand. */
export function classifyGin(handIds: CardId[], melds: Meld[]): GinType {
  const usedJoker = melds.some((m) => m.cards.some((c) => isJokerId(c)));
  const realCards = handIds.filter((id) => !isJokerId(id)).map(makeCard);
  const suits = new Set(realCards.map((c) => c.suit));
  const allSameSuit = suits.size <= 1;

  if (allSameSuit && usedJoker) return "suit_joker_gin";
  if (allSameSuit && !usedJoker) return "suit_gin";
  if (usedJoker) return "joker_gin";
  return "normal_gin";
}

/**
 * Resolves the `__JOKER__` placeholder cards in a solved meld list back to
 * actual joker card ids from the hand, so the client can render exactly
 * which physical card filled which slot.
 */
export function resolveJokerPlaceholders(melds: RealMeld[], jokerIdsInHand: CardId[]): Meld[] {
  const pool = [...jokerIdsInHand];
  return melds.map((m) => ({
    type: m.type,
    cards: m.cards.map((c) => (c === "__JOKER__" ? pool.shift()! : c)),
  }));
}
